<html>

<?php $__env->startSection('title', 'Login'); ?>

  <body class="my-login-page">
  <section class="h-100">
    <div class="container h-100">
      <div class="row justify-content-md-center h-100">
        <div class="card-wrapper">
          <div class="card fat top">
            <div class="card-body">
              <h4 class="card-title"> 登陆 </h4>
              <form action="login" method="post">
                <?php if(request()->session()->has('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(request()->session()->get('status')); ?>

                    </div>
                <?php endif; ?>
                <div class="form-group">
                  <label for="email">邮箱 <span class="badge" style="color:#888">Email</span></label>

                  <input id="email" type="email" class="form-control" name="email" value="" required autofocus>
                </div>

                <div class="form-group">
                    
                  <label for="password">密码 <span class="badge" style="color:#888">Password</span>
                    <a href="forgot.html" class="float-right">
                       找回 Forget?
                    </a>
                  </label>
                  <input id="password" type="password" class="form-control" name="password" required data-eye>
                </div>

                <div class="form-group no-margin">
                  <button type="submit" class="btn btn-primary btn-block">
                    Go!
                  </button>
                </div>
            </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  </body>
</html>
<?php echo $__env->make('head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>