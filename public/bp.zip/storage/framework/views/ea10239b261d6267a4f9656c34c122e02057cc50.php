<?php $__env->startSection('content'); ?>


<body>
	
<div class="container" style="margin-bottom:50px;">
<div>
	<?php if(request()->page != 1): ?>
	<a href="?page=<?php echo e(request()->page - 1); ?>">
	<button class="btn btn-secondary">Back</button>
	</a>
	<?php endif; ?>
	<?php if(request()->page != $res[1]): ?>
	<a href="?page=<?php echo e(request()->page + 1); ?>">
	<button class="btn btn-primary">Next</button>
	</a>
	<?php endif; ?>
	<div class="btn-group">
    <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">Go
	    <span class="caret"></span>
	</button>
    <div class="dropdown-menu">
    	<?php for($i = 1; $i <= $res[1]; $i++): ?>
    		<a class="dropdown-item" href="?page=<?php echo e($i); ?>">Page <?php echo e($i); ?></a>
		<?php endfor; ?>
	    
	</div>
</div>
<div id="root" />
<?php echo $res[0]; ?>

</div>
<div>
	<?php if(request()->page != 1): ?>
	<a href="?page=<?php echo e(request()->page - 1); ?>">
	<button class="btn btn-secondary">Back</button>
	</a>
	<?php endif; ?>
	<?php if(request()->page != $res[1]): ?>
	<a href="?page=<?php echo e(request()->page + 1); ?>">
	<button class="btn btn-primary">Next</button>
	</a>
	<?php endif; ?>
</div>


</div>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>