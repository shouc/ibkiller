
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" type="text/css" href="/static/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="/static/css/my-login.css">
    <script src="/static/js/jquery.min.js"></script>
    <script src="/static/bootstrap/js/bootstrap.min.js"></script>
    <script src="/static/js/my-login.js"></script>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    <style>
    body.my-login-page {
        background-color: #f7f9fb;
        font-size: 14px;
        background-image: url("/static/img/backgroud1.png");
        background-position: center 0;  
      background-repeat: no-repeat;  
      background-attachment: fixed; 
      background-size: cover;  
      -webkit-background-size: cover;  
      -o-background-size: cover;  
      -moz-background-size: cover;  
      -ms-background-size: cover;


    }

    .top {
        margin-top: 140px;
    }

    .my-login-page .card-wrapper {
        width: 400px;
        margin: 0;
    }

    .my-login-page .card {
        border-color: transparent;
        box-shadow: 0 0 40px rgba(0,0,0,.05);
    }

    .my-login-page .card.fat {
        padding: 10px;
    }

    .my-login-page .card .card-title {
        margin-bottom: 30px;
    }

    .my-login-page .form-control {
        border-width: 2.3px;
    }

    .my-login-page .form-group label {
        width: 100%;
    }

    .my-login-page .btn.btn-block {
        padding: 12px 10px;
    }

    .my-login-page .margin-top20 {
        margin-top: 20px;
    }

    .my-login-page .no-margin {
        margin: 0;
    }

    .my-login-page .footer {
        margin: 40px 0;
        color: #888;
        text-align: center;
    }

    @media  screen and (max-width: 425px) {
        .my-login-page .card-wrapper {
            width: 90%;
            margin: 0 auto;
        }
    }

    @media  screen and (max-width: 320px) {
        .my-login-page .card.fat {
            padding: 0;
        }

        .my-login-page .card.fat .card-body {
            padding: 15px;
        }
    }
    </style>
</head>
