git add -A;git commit -m "prod commit";git push origin master;
